import React, { useState, useEffect } from 'react';
import { 
  Navbar, 
  NavbarBrand, 
  Collapse, 
  Nav, 
  NavItem, 
  Button, 
  Table,
} from 'reactstrap';
import { useParams } from "react-router-dom";

function Specific() {
  const [activeTab, setActiveTab] = useState('hardware'); 
  const [hardwareData, setHardwareData] = useState([]); 
  const [processData, setProcessData] = useState([]); 
  const [networkData, setNetworkData] = useState([]); 
  const { id } = useParams(); // Extract the 'id' from the URL

  React.useEffect(() => {
    // Fetch or use the 'id' to get detailed data
    console.log("Fetched ID:", id);
  }, [id]);

  useEffect(() => {
    const fetchHardwareData = async () => {
      try {
        const response = await fetch(`http://10.1.32.92:5000/hardware-specific/${id}`); 
        const data = await response.json();
        setHardwareData(data);
      } catch (error) {
        console.error('Error fetching hardware data:', error);
      }
    };

    const fetchProcessData = async () => {
      try {
        const response = await fetch(`http://10.1.32.92:5000/network-specific/${id}`); 
        const data = await response.json();
        setProcessData(data);
      } catch (error) {
        console.error('Error fetching process data:', error);
      }
    };

    const fetchNetworkData = async () => {
      try {
        const response = await fetch(`http://10.1.32.92:5000/network-specific/${id}`); 
        const data = await response.json();
        setNetworkData(data);
      } catch (error) {
        console.error('Error fetching network data:', error);
      }
    };

    if(id) {
      fetchHardwareData();
    fetchProcessData();
    fetchNetworkData();
    }

    
  }, [id]); 

  const handleTabClick = (tabName) => {
    setActiveTab(tabName);
  };

  return (
    <div>
      <h1>{id}</h1>
      <Navbar color="primary" dark expand="md" className="mb-4 rounded">
        <div className="d-flex align-items-center">
          <NavbarBrand href="/" className="text-white">
            Software Data
          </NavbarBrand>
        </div>
        <Collapse navbar>
          <Nav className="me-auto" navbar>
            <NavItem>
              <Button 
                color={activeTab === 'hardware' ? 'primary' : 'light'} 
                size="sm" 
                className="me-2" 
                onClick={() => handleTabClick('hardware')}
              >
                Hardware Info
              </Button>
            </NavItem>
            <NavItem>
              <Button 
                color={activeTab === 'process' ? 'primary' : 'light'} 
                size="sm" 
                className="me-2" 
                onClick={() => handleTabClick('process')}
              >
                Active Process
              </Button>
            </NavItem>
            <NavItem>
              <Button 
                color={activeTab === 'network' ? 'primary' : 'light'} 
                size="sm" 
                className="me-2" 
                onClick={() => handleTabClick('network')}
              >
                Network Details
              </Button>
            </NavItem>
          </Nav>
        </Collapse>
      </Navbar>

      {/* Display the corresponding table based on the active tab */}
      {activeTab === 'hardware' && <HardwareTable data={hardwareData} />} 
      {activeTab === 'process' && <ProcessTable data={processData} />} 
      {activeTab === 'network' && <NetworkTable data={networkData} />} 
    </div>
  );
}

// Placeholder table components (replace with your actual table implementations)
const HardwareTable = ({ data }) => (
  <Table bordered hover>
  <thead>
    <tr>
      <th>UID</th>
      <th>CPU ID</th>
      <th>Mother Board ID</th>
      {/* <th>Joined</th>
      <th>Recent Update</th> */}
    </tr>
  </thead>
  <tbody>
    {/* Dynamically generate rows */}
    {data.map((row, index) => (
      <tr key={index}>
        <td>{row.UID}</td>
        <td>{row.CPUid}</td>
        <td>{row.MBid}</td>
        {/* <td>{formatTimestamp(row.joined_at)}</td>
        <td>{formatTimestamp(row.updated_at)}</td> */}
        
      </tr>
    ))}
  </tbody>
</Table>
);

const ProcessTable = ({ data }) => (
  <Table bordered hover>
  <thead>
    <tr>
      <th>ID</th>
      <th>UID</th>
      <th>Host Name</th>
      <th>IP Address</th>
      {/* <th>Joined</th>
      <th>Recent Update</th> */}
      <th>View Details</th>
    </tr>
  </thead>
  <tbody>
    {/* Dynamically generate rows */}
    {data.map((row, index) => (
      <tr key={index}>
        <td>{row.client_id}</td>
        <td>{row.UID}</td>
        <td>{row.hostname}</td>
        <td>{row.ip_address}</td>
        {/* <td>{formatTimestamp(row.joined_at)}</td>
        <td>{formatTimestamp(row.updated_at)}</td> */}
        
      </tr>
    ))}
  </tbody>
</Table>
);

const NetworkTable = ({ data }) => (
  <Table bordered hover>
  <thead>
    <tr>
      <th>UID</th>
      <th>Interface</th>
      <th>IP address</th>
      <th>Mac Address</th>
      {/* <th>Joined</th>
      <th>Recent Update</th> */}
    </tr>
  </thead>
  <tbody>
    {/* Dynamically generate rows */}
    {data.map((row, index) => (
      <tr key={index}>
        <td>{row.UID}</td>
        <td>{row.interface}</td>
        <td>{row.ip_address}</td>
        <td>{row.mac_address}</td>
        {/* <td>{formatTimestamp(row.joined_at)}</td>
        <td>{formatTimestamp(row.updated_at)}</td> */}
        
      </tr>
    ))}
  </tbody>
</Table>
);

export default Specific;