const command = `powershell -Command "Get-Process | Where-Object { $_.ProcessName -match 'mcafee|Trend Micro Common Client Real-time Scan Service (64-bit)|avast|kaspersky|norton|trendmicro|pccNTMon|TmsaInstance64|CNTAoSMgr|TmListen|Ntrtscan' } | Select-Object Name, Id, CPU, MemoryUsage"`;

app.post('/api/client-info', (req, res) => {
    const clinetData = req.body.clinetData;

    //Inserting clinet data into MySQL (clinet table)
    const query = 'INSERT INTO client (hostname,ip_address,mac_address) VALUES (?,?,?)';
      const promises = clientData.map(interface => {
        return db.execute(query, [interface.interfaceName, interface.ipAddress, interface.macAddress,]);
    });

    Promise.all(promises)
        .then(() => res.send('Network data inserted successfully!'))
        .catch(err => res.status(500).send(err));
})


app.post('/api/network-info', (req, res) => {
    const networkData = req.body.networkData;
    
    // Insert network data into MySQL (network table)
    const query = 'INSERT INTO client (hostname, ip_address, mac_address) VALUES (?, ?, ?)';
    const promises = networkData.map(interface => {
        return db.execute(query, [interface.interfaceName, interface.ipAddress, interface.macAddress,]);
    });

    Promise.all(promises)
        .then(() => res.send('Network data inserted successfully!'))
        .catch(err => res.status(500).send(err));
});




// Insert system data into MySQL (system table)
const query2 = 'INSERT INTO sys_info (client_id, hostname, tmemory, fmemory, sys_release, sys_type, sys_arch) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
db.execute(query2, [
    clientId,
    systemData.hostname,
    systemData.totalMemory,
    systemData.freeMemory,
    systemData.release,
    systemData.type,
    systemData.arch,
])
.then(() => res.send('System data inserted successfully!'))
.catch(err => res.status(500).send(err));











fetch('http://localhost:3000/api/network-info', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ networkData: systemInfo.networkInterfaces })
  }).catch(error => console.error('Error sending network data:', error));


  // fetch('http://localhost:3000/api/client-info', {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify({ systemData: systemInfo, networkData: systemInfo.networkInterfaces })
  // }).catch(error => console.error('Error sending network data:', error));



  //To execute the CMD commands
function executeCommand(command) {
    return new Promise((resolve, reject) => {
      exec(command, (error, stdout, stderr) => {
        if (error) {
          reject(stderr.trim());
        } else {
          resolve(stdout.trim());
        }
      });
    });
  }
  
  
  //To gether system information
  async function getSystemInfo() {
    try {
      const cpuInfo = await executeCommand('wmic cpu get ProcessorId,Name,Manufacturer /format:list');
      const motherboardInfo = await executeCommand('wmic baseboard get SerialNumber,Manufacturer,Product /format:list');
  
      return {
        cpuInfo,
        motherboardInfo,
      };
    } catch (error) {
      console.error('Error gathering system info:', error);
      return { error: error.message };
    }
  }





  function fetchAntivirusDetails() {
    const command = `powershell -Command "Get-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*', 'HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*' | Where-Object { $_.DisplayName -like '*antivirus*' -or $_.DisplayName -like '*McAfee*' -or $_.DisplayName -like '*Avast*' -or $_.DisplayName -like '*Kaspersky*' -or $_.DisplayName -like '*Trend Micro*' } | Select-Object DisplayName, DisplayVersion, Publisher"`;
  
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error(`Error executing PowerShell command: ${error.message}`);
        sendToRenderer('antivirus-data', { error: error.message });
        return;
      }
  
      if (stderr) {
        console.error(`PowerShell stderr: ${stderr}`);
        sendToRenderer('antivirus-data', { error: stderr });
        return;
      }
  
      try {
        const antivirusData = stdout
          .trim()
          .split('\n')
          .slice(2) // Skip headers
          .map(line => {
            const [displayName, displayVersion, Publisher] = line.split(/\s{3,}/).map(item => item.trim());
            return { displayName, displayVersion, Publisher };
          });
  
        console.log('Antivirus Details:', antivirusData); // Debug log
        sendToRenderer('antivirus-data', { data: antivirusData });
        sendAVDataToServer();
      } catch (parseError) {
        console.error('Error parsing PowerShell output:', parseError);
        sendToRenderer('antivirus-data', { error: 'Error parsing PowerShell output' });
      }
    });
  }