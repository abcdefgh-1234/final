const { ipcRenderer } = require('electron');

// Handle system information

ipcRenderer.on('system-info', (event, systemInfo) => {
  const systemInfoContainer = document.getElementById('system-info');
  systemInfoContainer.innerHTML = `
      <p><strong>Platform:</strong> ${systemInfo.platform}</p>
      <p><strong>Architecture:</strong> ${systemInfo.arch}</p>
      <p><strong>CPUs:</strong> ${systemInfo.cpus}</p>
      <p><strong>Total Memory:</strong> ${formatBytes(systemInfo.totalMemory)}</p>
      <p><strong>Free Memory:</strong> ${formatBytes(systemInfo.freeMemory)}</p>
      <p><strong>Hostname:</strong> ${systemInfo.hostname}</p>
      <p><strong>Release:</strong> ${systemInfo.release}</p>
      <p><strong>Type:</strong> ${systemInfo.type}</p>
      <p><strong>Uptime:</strong> ${formatUptime(systemInfo.uptime)}</p>

      <div class="network-info">
          <h3>Network Interfaces:</h3>
          <ul>
              ${systemInfo.networkInterfaces.map(interface => `
                  <li>
                      <strong>${interface.interfaceName}</strong><br>
                      <strong>MAC Address:</strong> ${interface.macAddress}<br>
                      <strong>IP Address:</strong> ${interface.ipAddress}
                  </li>
              `).join('')}
          </ul>
      </div>

      <h3>Patches:</h3>
      <table>
          <thead>
              <tr>
                  <th>HotFix ID</th>
                  <th>Description</th>
                  <th>Installed On</th>
                  <th>Installed By</th>
              </tr>
          </thead>
          <tbody>
              ${Array.isArray(systemInfo.patches) && systemInfo.patches.length > 0
                  ? systemInfo.patches.map(patch => `
                      <tr>
                          <td>${patch.hotFixID}</td>
                          <td>${patch.description}</td>
                          <td>${patch.installedOn}</td>
                          <td>${patch.installedBy}</td>
                      </tr>
                  `).join('')
                  : `<tr><td colspan="4">No patches found.</td></tr>`
              }
          </tbody>
      </table>
  `;
});

function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return (bytes / Math.pow(k, i)).toFixed(2) + ' ' + sizes[i];
}

function formatUptime(seconds) {
  const days = Math.floor(seconds / (24 * 3600));
  seconds %= (24 * 3600);
  const hours = Math.floor(seconds / 3600);
  seconds %= 3600;
  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${days}d ${hours}h ${minutes}m ${secs}s`;
}

// Handle software data
ipcRenderer.on('software-data', (event, data) => {
    const tableBody = document.querySelector('#software-table tbody');
    tableBody.innerHTML = ''; // Clear existing rows

    if (data.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="4">No software data available.</td>
        `;
        tableBody.appendChild(row);
    } else {
        data.forEach(software => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${software.Name || 'N/A'}</td>
                <td>${software.InstallLocation || 'N/A'}</td>
                <td>${software.InstallDate || 'N/A'}</td>
                <td>${software.Version || 'N/A'}</td>
            `;
            tableBody.appendChild(row);
        });
    }
});
