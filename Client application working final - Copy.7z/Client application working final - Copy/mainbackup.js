const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { exec } = require('child_process');
const WMIClient = require('wmi-client');  // WMI query module
const os = require('os');
const wmi = require('node-wmi'); // Ensure this is correctly imported
const csvParser = require('csv-parser');
const fs = require('fs');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true,
    }
  });

  mainWindow.loadFile('index.html');
  mainWindow.webContents.openDevTools();  

  // Fetch the software details using WMI query and send data to renderer
  fetchOfficeScanSoftware(); // To find anti virus info
  fetchSoftwareInfo();       // To get running software info
  getLatestHotfix();
}

app.whenReady().then(() => {
  createWindow();

  const systemInfo = {
    platform: os.platform(),
    arch: os.arch(),
    cpus: os.cpus().map(cpu => cpu.model).join(', '),
    totalMemory: os.totalmem(),
    freeMemory: os.freemem(),
    hostname: os.hostname(),
    release: os.release(),
    type: os.type(),
    uptime: os.uptime(),
    networkInterfaces: getNetworkInfo(),
    patches: getPatches()  // patches now holds a Promise
  };

  systemInfo.patches.then(patches => {
    systemInfo.patches = patches;

    mainWindow.webContents.on('did-finish-load', () => {
      mainWindow.webContents.send('system-info', systemInfo);
    });
  }).catch(error => {
    console.error("Error fetching system info:", error);
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});




function getLatestHotfix() {
  exec('wmic qfe get HotFixID /format:csv', (error, stdout, stderr) => {
    if (error || stderr) {
      const errorMessage = `Error fetching hotfix ID: ${error || stderr}`;
      sendToRenderer('update-output', errorMessage);
      return;
    }

    const lines = stdout.trim().split('\n');
    const hotfixes = lines.slice(1).map(line => line.split(',').pop().trim());
    let latestHotfix = hotfixes.pop();

    if (latestHotfix) {
      latestHotfix = latestHotfix.replace('KB', ''); // Trim "KB" from Hotfix ID
      console.log(`Latest Hotfix ID (trimmed): ${latestHotfix}`);
      sendToRenderer('update-output', `Latest Hotfix ID: ${latestHotfix}`);
      fetchReleaseDateFromCSV(latestHotfix);
    } else {
      console.log('No hotfixes found.');
      sendToRenderer('update-output', 'No hotfixes found on this system.');
    }
  });
}

// Fetch release date from the CSV file
function fetchReleaseDateFromCSV(hotfixID) {
  const csvFilePath = path.join(__dirname, 'patches.csv'); // Path to your CSV file
  let patchFound = false;

  // Read the CSV file
  fs.createReadStream(csvFilePath)
    .pipe(csvParser()) // Parse CSV
    .on('data', (row) => {
      // Check if the row contains an 'Article' field and compare the trimmed Hotfix ID with the 'Article' field
      if (row.Article && row.Article.trim() === hotfixID) {
        patchFound = true;
        const releaseDate = row.Releasedate || 'Release date not available';
        const message = `Hotfix ID: ${hotfixID}, Release Date: ${row.Releasedate}`;
        console.log(message); // Log the message
        sendToRenderer('display-patch-info', { hotfixID, releaseDate }); // Send message to the renderer process
      }
    })
    .on('end', () => {
      if (!patchFound) {
        // If the Hotfix ID was not found in the CSV
        const message = `Hotfix ID ${hotfixID} not found in the CSV file.`;
        console.log(message); // Log the not found message
        sendToRenderer('update-output', message); // Send message to renderer process
      }
    })
    .on('error', (err) => {
      console.error('Error reading the CSV file:', err);
      sendToRenderer('update-output', `Error reading the CSV file: ${err.message}`);
    });
}

function sendToRenderer(channel, message) {
  if (mainWindow && mainWindow.webContents) {
    mainWindow.webContents.send(channel, message); // Sends message to the renderer process
  }
}




// Fetch OfficeScan software info using PowerShell
function fetchOfficeScanSoftware() {
  const command = `powershell -Command "Get-WmiObject -Class 'Win32_Product' -Namespace 'root\\cimv2' -ComputerName '.' -Filter \\\"Name like '%OfficeScan%'\\\""`; 

  exec(command, (err, stdout, stderr) => {
    if (err) {
      console.error(`Error executing PowerShell command: ${err}`);
      return;
    }
    
    if (stderr) {
      console.error(`PowerShell stderr: ${stderr}`);
      return;
    }

    try {
      const result = stdout; // The output of the command
      mainWindow.webContents.send('officescan-data', result); // Send data to renderer
    } catch (parseError) {
      console.error('Error parsing PowerShell output:', parseError);
    }
  });
}

function getNetworkInfo() {
  const networkInterfaces = os.networkInterfaces();
  const interfaces = [];

  for (let interfaceName in networkInterfaces) {
    networkInterfaces[interfaceName].forEach(interfaceDetails => {
      if (interfaceDetails.family === 'IPv4' && interfaceDetails.internal === false) {
        interfaces.push({
          interfaceName: interfaceName,
          macAddress: interfaceDetails.mac,
          ipAddress: interfaceDetails.address
        });
      }
    });
  }

  return interfaces;
}

// Patch updates
function getPatches() {
  if (os.platform() !== 'win32') {
    return Promise.resolve('Patch information not available for this platform.');
  }

  return new Promise((resolve, reject) => {
    wmi.Query({
      class: 'Win32_QuickFixEngineering'
    }, (err, result) => {
      if (err) {
        reject('Failed to retrieve patch information');
      } else {
        if (result && result.length > 0) {
          const patches = result.map(patch => {
            return {
              description: patch.Description,
              installedOn: patch.InstalledOn,
              hotFixID: patch.HotFixID,
              installedBy: patch.InstalledBy,
            };
          });
          resolve(patches);
        } else {
          resolve('No patches found.');
        }
      }
    });
  });
}

//WMI querry to get running process
function fetchSoftwareInfo() {
  const client = new WMIClient({
    host: 'localhost',
    username: '', 
    password: '', 
  });

  const Query = `SELECT Name, InstallLocation, InstallDate, Version FROM Win32_Product`;

  client.query(Query, function (err, result) {
    if (err) {
      console.error('WMI Query Error:', err);
      return;
    }

    if (result.length === 0) {
      console.log('No software found.');
    } else {
      console.log(`Found ${result.length} software items.`);  
    }
    
    // Send the result to the renderer process
    mainWindow.webContents.send('software-data', result);
  });
}
